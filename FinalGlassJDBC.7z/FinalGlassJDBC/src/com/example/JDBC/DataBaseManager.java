package com.example.JDBC;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class DataBaseManager
{
	public static Connection c = null;
	public static Statement stmt = null;
	public static String DataBaseName;
	public static int currAdjectiveID;

	
	public static void setDataBaseName(String DataBaseNameIn) 
	{
		DataBaseName = DataBaseNameIn;
	}

	public static void setAdjectiveIDCount(int adjectiveIDCountIn)
	{
		currAdjectiveID = adjectiveIDCountIn;
	}

	public static int getMaxPersonID() 
	{
		int count = 0;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName	+ ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Persons;");
			while (rs.next())
				count++;
			rs.close();
			stmt.close();
			c.close();
			return count;
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
			return 0;
		}
	}
	
	public static int getMaxAdjectiveID()
	{
		int count = 0;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName	+ ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Adjectives;");
			while (rs.next())
				count++;
			rs.close();
			stmt.close();
			c.close();
			return count;
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
			return 0;
		}
	}

	public static void TablePersonsInserting(String PersonName, String PersonGender, String PersonLocatin) 
	{
		int count = 0;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName	+ ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Persons Where Name='"+PersonName+"';");
			while (rs.next()) 
				count++;
			rs = stmt.executeQuery("SELECT * FROM Persons Where Gender='"+PersonGender+"';");
			while (rs.next()) 
				count++;
			rs = stmt.executeQuery("SELECT * FROM Persons Where Location='"+PersonLocatin+"';");
			while (rs.next()) 
				count++;
			rs.close();
			if(count != 4)
			{
			String sql = "INSERT INTO Persons (Name,Gender,Location) VALUES (" + "'"+ PersonName + "'" + ", " + "'" + PersonGender + "'" + ", "	+ "'" + PersonLocatin + "'" + ");";
			stmt.executeUpdate(sql);
			}
			else
			{
				System.out.println("Person "+PersonName+" is allready exist");
			}
			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
	}

	public static void TablePersonsOutStreaming() 
	{
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName	+ ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Persons;");
			while (rs.next()) {
				int id = rs.getInt("ID");
				String name = rs.getString("Name");
				String Gender = rs.getString("Gender");
				String Location = rs.getString("Location");
				System.out.println("ID = " + id);
				System.out.println("Name = " + name);
				System.out.println("Gender = " + Gender);
				System.out.println("Location = " + Location);
				System.out.println();
			}
			rs.close();
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
	}

	public static void TablePersonDeletor(String PersonName) 
	{
		int currNameID=0;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName	+ ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rsForNameID = stmt.executeQuery("SELECT * FROM Persons WHERE Name='" + PersonName	+ "';");
			while (rsForNameID.next()) 
				 currNameID = rsForNameID.getInt("ID");
			String sql = "DELETE from Persons where ID=" + currNameID + ";";
			stmt.executeUpdate(sql);
			c.commit();
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
	}

	public static void TableAdjectivesInserting(String PersonName, String Adjective)
	{
		int currAdjectiveID = 0;
		int PersonID = 0;
		int count = 0;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName	+ ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rsForAdjID = stmt.executeQuery("SELECT * FROM Adjectives where Adjective='"	+ Adjective + "';");
			while (rsForAdjID.next())
			{
			currAdjectiveID = rsForAdjID.getInt("ID");
			}
			if (currAdjectiveID == 0)
			{
				String sql = "INSERT INTO Adjectives (Adjective)" + "VALUES (" + "'" + Adjective + "'"+ ");";
				stmt.executeUpdate(sql);
				rsForAdjID = stmt.executeQuery("SELECT * FROM Adjectives where Adjective='"	+ Adjective + "';");
				currAdjectiveID = rsForAdjID.getInt("ID");
			}
			ResultSet rsForNameID = stmt.executeQuery("SELECT * FROM Persons WHERE Name='" + PersonName	+ "';");
			while(rsForNameID.next())
			{
				PersonID = rsForNameID.getInt("ID");
			}
			if(PersonID==0)
			{
				System.out.println("no such person, sorry :(");
			}
			else{
			rsForNameID = stmt.executeQuery("SELECT * FROM Connection WHERE PersonID='" + PersonID	+ "' and AdjectiveID='" + currAdjectiveID	+ "';");
			while (rsForNameID.next()) 
			{
				count++;
			}
			if(count == 0)
			{
					String sql = "INSERT INTO Connection (PersonID,AdjectiveID) VALUES ("+ "'" + PersonID + "'" + ",  " + "'" + currAdjectiveID + "'"+ ");";
					stmt.executeUpdate(sql);
			}
			}
			rsForAdjID.close();
			rsForNameID.close();
			stmt.close();
			c.commit();
			c.close();			
		}catch(Exception e)
		{
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
	}

	public static void TableAdjectivesOutStreaming()
	{
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName	+ ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Adjectives;");
			while (rs.next()) 
			{
				int id = rs.getInt("ID");
				String adjective = rs.getString("Adjective");
				System.out.println("ID = " + id);
				System.out.println("Adjective = " + adjective);
				System.out.println();
			}
			rs.close();
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
	}
	
	public static void TableAdjectiveDeletor(int AdjectiveID) 
	{
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName	+ ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			String sql = "DELETE from Adjectives where ID=" + AdjectiveID + ";";
			stmt.executeUpdate(sql);
			c.commit();
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
	}

	public static void TableConnectionOutStreaming() 
	{
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName
					+ ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Connection;");
			while (rs.next()) {
				String conP = rs.getString("PersonID");
				String conA = rs.getString("AdjectiveID");
				System.out.println("Connectin of Person and Adjective = "
						+ conP + " - " + conA);
				System.out.println();
			}
			rs.close();
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
	}
	
	public static void TableConnectionDeletor(int PersonID) 
	{
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName	+ ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			String sql = "DELETE from Connection where PersonID=" + PersonID + ";";
			stmt.executeUpdate(sql);
			c.commit();
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
	}

	public static void DeleteDataBase() 
	{
		try {
			File fr = new File("C:\\Users\\Administrator.LAB629.001\\Desktop\\eclipse-standard-kepler-SR1-win32-x86_64\\eclipse\\workspace\\FinalGlassJDBC\\GlassDataBase.db");
			fr.delete();
		} catch (Exception e) {	e.printStackTrace();}
	}

	public static ArrayList<String> GetAdjectivesFromNames(String Name) 
	{
		ArrayList<String> returnedAdjectives = new ArrayList<String>();
		int currNameID = 0;
		try {
			// Getting Database
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName	+ ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			// Query for Name in Names to get ID
			ResultSet rsForNameID = stmt.executeQuery("SELECT * FROM Persons WHERE Name='" + Name	+ "';");
			while (rsForNameID.next()) 
			{
				currNameID = rsForNameID.getInt("ID");
			}
			rsForNameID.close();

			// Query for corresponding adj IDs
			ResultSet rsForAdjID = stmt.executeQuery("SELECT * FROM Connection where PersonID='"	+ currNameID + "';");

			// Get adjective IDs and add to adjIDs arrayList
			ArrayList<Integer> adjIDs = new ArrayList<Integer>();
			while (rsForAdjID.next())
				adjIDs.add(rsForAdjID.getInt("AdjectiveID"));

			// For each adj ID in adjIDs get actual adj from Adjectives Table
			ResultSet rsForAdjFromAdjID = null;
			for (Integer adjId : adjIDs) 
			{
				rsForAdjFromAdjID = stmt.executeQuery("SELECT * FROM Adjectives where ID='"+ adjId + "';");
				while (rsForAdjFromAdjID.next())
					returnedAdjectives.add(rsForAdjFromAdjID.getString("Adjective"));
			}
			rsForAdjFromAdjID.close();
			rsForAdjID.close();
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		return returnedAdjectives;
	}
		
	
	public static  void deleteDBROW(String Name)
	{
		ArrayList<Integer> adjIDs = new ArrayList<Integer>();
		ArrayList<Integer> nameIDs = new ArrayList<Integer>();
		int currNameID = 0;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName	+ ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rsForNameID = stmt.executeQuery("SELECT * FROM Persons WHERE Name='" + Name	+ "';");
			while(rsForNameID.next())
				currNameID = rsForNameID.getInt("ID");
			rsForNameID.close();
			String sql = "DELETE from Persons where ID=" + currNameID + ";";
			stmt.executeUpdate(sql);
			c.commit();
			ResultSet rsForAdjID = stmt.executeQuery("SELECT * FROM Connection where PersonID='"	+ currNameID + "';");
			while (rsForAdjID.next())
				adjIDs.add(rsForAdjID.getInt("AdjectiveID"));
				sql = "DELETE FROM Connection WHERE PersonID=" + currNameID	+ ";";
				stmt.executeUpdate(sql);
				c.commit();
			rsForAdjID.close();
			
			for (int i = 0; i<adjIDs.size(); i++)
			{	for(int j=0; j<nameIDs.size(); j++){
				nameIDs.remove(j);
				
			}
				ResultSet rsConnLeft = stmt.executeQuery("SELECT * FROM Connection where AdjectiveID='"	+ Integer.toString(adjIDs.get(i)) + "';");
				while(rsConnLeft.next())
					nameIDs.add(rsConnLeft.getInt("PersonID"));
				rsConnLeft.close();
			if(nameIDs.size()==0)
			{
				
				sql = "DELETE from Adjectives where ID=" + adjIDs.get(i) + ";";
				stmt.executeUpdate(sql);
				c.commit();
				
			}}
			stmt.close();
			c.close();		
			}
		catch (Exception e) 
			{
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
}

}