package com.example.JDBC;

public class Main {
	public static void main(String args[]) 
	{
		String DataBaseName = "GlassDataBase";
		DataBaseCreator.init(DataBaseName);
		//DataBaseManager.TablePersonsInserting("Robert_Asaturyan",	"Male", "Tumo");
		//DataBaseManager.TablePersonsInserting("Artyom_Dangizyan", "Male", "Komitas");
		//DataBaseManager.TableAdjectivesInserting("Robert_Asaturyan", "Developer");
		//DataBaseManager.TableAdjectivesInserting("Robert_Asaturyan", "Google_Glasser");		
		//DataBaseManager.TableAdjectivesInserting("Artyom_Dangizyan", "Developer");
		DataBaseManager.TableAdjectivesInserting("Artyom", "Developer");
		//System.out.println(DataBaseManager.GetAdjectivesFromNames("Artyom_Dangizyan"));
		//DataBaseManager.deleteDBROW("Robert_Asaturyan");
		//DataBaseManager.TablePersonsOutStreaming();
				
	}
}
