package com.example.JDBC;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DataBaseCreator 
{
	public static void init(String DataBaseName) 
	{
		Connection c = null;
		Statement stmt = null;
		File dbFile = new File("C:\\Users\\Administrator.LAB629.001\\Desktop\\eclipse-standard-kepler-SR1-win32-x86_64\\eclipse\\workspace\\FinalGlassJDBC\\GlassDataBase.db");
		if(!dbFile.exists())
		{
			System.out.println("MAKING DATABASE");
			try {
				Class.forName("org.sqlite.JDBC");
				c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName + ".db");
			} catch (Exception e) {
				System.err.println(e.getClass().getName() + ": " + e.getMessage());
				System.exit(0);
			}
			try {
				Class.forName("org.sqlite.JDBC");
				c = DriverManager.getConnection("jdbc:sqlite:" + DataBaseName + ".db");
				stmt = c.createStatement();
				String sql = "CREATE TABLE Persons"
						+ "(ID 		      INTEGER PRIMARY KEY   AUTOINCREMENT,"
						+ "Name           TEXT   			 NOT NULL,"
						+ "Gender         TEXT     		  	 NOT NULL,"
						+ "Location       TEXT)";
				stmt.executeUpdate(sql);
				sql = "CREATE TABLE Adjectives"
						+ "(ID 			      INTEGER PRIMARY KEY   AUTOINCREMENT,"
						+ "Adjective          TEXT)";
				stmt.executeUpdate(sql);
				sql = "CREATE TABLE Connection"
						+ "(PersonID 			   INT     NOT NULL,"
						+ "AdjectiveID        	   INT)";
				stmt.executeUpdate(sql);
				stmt.close();
				c.close();
				
			} catch (Exception e) {
				System.err.println(e.getClass().getName() + ": " + e.getMessage());
				System.exit(0);
			}
		}
		DataBaseManager.setDataBaseName(DataBaseName);
	}
}
